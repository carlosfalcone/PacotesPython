import matplotlib.pyplot as plt

def plot_funcao(pontos_x,pontos_y):
    plt.scatter(x=pontos_x,y=pontos_y)
    plt.xlabel('Eixo x')
    plt.ylabel('Eixo y')