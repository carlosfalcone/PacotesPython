# package_name

Description. 
The package package_name is used to:
	- Plot simple math functions

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install Funcoes_matematicas
```

## Author
Carlos Falcone

## License
[MIT](https://choosealicense.com/licenses/mit/)